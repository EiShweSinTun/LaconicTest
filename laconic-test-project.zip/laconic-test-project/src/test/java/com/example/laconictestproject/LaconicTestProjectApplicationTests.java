package com.example.laconictestproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaconicTestProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
