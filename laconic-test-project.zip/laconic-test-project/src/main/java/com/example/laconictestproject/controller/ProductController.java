package com.example.laconictestproject.controller;

import com.example.laconictestproject.entities.Product;
import com.example.laconictestproject.entities.Role;
import com.example.laconictestproject.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/create")
    public ResponseEntity<?> registerUser(@RequestBody Product product){
        productService.createProduct(product);
        return ResponseEntity.status(HttpStatus.OK).body(product);
    }

    @GetMapping("/view")
    public ResponseEntity<?> viewUser(@RequestBody Product product){
        return ResponseEntity.status(HttpStatus.OK).body(productService.findAllProducts());
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateUser(@RequestBody Product product){
        productService.updateProduct(product);
        return ResponseEntity.status(HttpStatus.OK).body(product);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteUser(@RequestBody Product product ){
        productService.deleteProduct(product);
        return ResponseEntity.status(HttpStatus.OK).body("User is Deleted");
    }

}
