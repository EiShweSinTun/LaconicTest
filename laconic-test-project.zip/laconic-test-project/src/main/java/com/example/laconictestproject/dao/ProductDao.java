package com.example.laconictestproject.dao;

import com.example.laconictestproject.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDao extends JpaRepository<Product, Integer> {
}
