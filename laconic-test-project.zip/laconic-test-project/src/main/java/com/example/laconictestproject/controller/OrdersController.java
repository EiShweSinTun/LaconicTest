package com.example.laconictestproject.controller;

import com.example.laconictestproject.entities.Orders;
import com.example.laconictestproject.service.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/order")
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    @PostMapping("/create")
    public ResponseEntity<?> createOrder(Orders orders){
        ordersService.createOrder(orders);
        return ResponseEntity.status(HttpStatus.OK).body(orders);
    }

    @GetMapping("/view")
    public ResponseEntity<?> viewOrders(){
        return ResponseEntity.status(HttpStatus.OK).body(ordersService.getOrderList());
    }

    @PutMapping("/update")
    public void updateOder(Orders orders){
        ordersService.updateOrder(orders);
    }

}
