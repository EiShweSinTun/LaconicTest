package com.example.laconictestproject.dao;

import com.example.laconictestproject.entities.Cart;
import com.example.laconictestproject.entities.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartDao extends JpaRepository<Cart, Integer> {

    Cart findCartByUsers(Users user);
}
