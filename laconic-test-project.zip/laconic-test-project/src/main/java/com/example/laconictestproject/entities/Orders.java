package com.example.laconictestproject.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int orderId;
    @ManyToMany
    private List<Product> productList;
    private double orderTotalPrice;
    private String deliveryAddress;

    @OneToOne
    private Users users;

}
