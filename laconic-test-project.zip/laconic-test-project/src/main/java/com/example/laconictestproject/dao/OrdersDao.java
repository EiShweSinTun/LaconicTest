package com.example.laconictestproject.dao;

import com.example.laconictestproject.entities.Orders;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdersDao extends JpaRepository<Orders, Integer> {
}
