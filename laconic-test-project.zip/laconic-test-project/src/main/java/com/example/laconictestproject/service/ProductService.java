package com.example.laconictestproject.service;

import com.example.laconictestproject.dao.ProductDao;
import com.example.laconictestproject.entities.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductDao productDao;

    @Transactional
    public void createProduct(Product product){
        productDao.save(product);
    }

    @Transactional
    public void deleteProduct(Product product){
        productDao.delete(product);
    }

    public List<Product> findAllProducts(){
        return productDao.findAll();
    }

    @Transactional
    public void updateProduct(Product product){
        productDao.saveAndFlush(product);
    }

    public Product findProuductById(int id){
        return productDao.getById(id);
    }

}
