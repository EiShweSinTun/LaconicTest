package com.example.laconictestproject.entities;

public enum Role {

    USER

}
