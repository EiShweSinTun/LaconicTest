package com.example.laconictestproject.service;

import com.example.laconictestproject.dao.CartDao;
import com.example.laconictestproject.entities.Cart;
import com.example.laconictestproject.entities.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartDao cartDao;

    @Transactional
    public void createCart(Cart cart){
        cartDao.save(cart);
    }

    @Transactional
    public void deleteCart(Cart cart){
        cartDao.delete(cart);
    }

    public List<Cart> findAllCart(){
        return cartDao.findAll();
    }

    public Cart findCartById(int id){
        return cartDao.getById(id);
    }

    @Transactional
    public void updateCart(Cart cart){
        cartDao.saveAndFlush(cart);
    }

    public Cart findCartByUser(Users users){
        return cartDao.findCartByUsers(users);
    }
}
