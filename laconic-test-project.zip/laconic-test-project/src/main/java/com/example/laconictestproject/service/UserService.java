package com.example.laconictestproject.service;

import com.example.laconictestproject.dao.UsersDao;
import com.example.laconictestproject.entities.Cart;

import com.example.laconictestproject.entities.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UsersDao usersDao;

    @Autowired
    private CartService cartService;

    @Transactional
    public void createUser(Users users){
        Cart cart = new Cart();
        users.setCart(cart);
        cartService.createCart(cart);
        usersDao.save(users);
    }

    @Transactional
    public void deleteUser(Users users){
        cartService.deleteCart(users.getCart());
        usersDao.delete(users);
    }

    public List<Users> findAllUser(){
        return usersDao.findAll();
    }

    public Users findUserById(int id){
        return usersDao.getById(id);
    }

    @Transactional
    public void updateUser(Users user){
        usersDao.saveAndFlush(user);
    }

    public Users findUserByUsername(String name){
        return usersDao.findByUsername(name);
    }
}
