package com.example.laconictestproject.controller;

import com.example.laconictestproject.entities.Cart;
import com.example.laconictestproject.entities.Role;
import com.example.laconictestproject.entities.Users;
import com.example.laconictestproject.service.CartService;
import com.example.laconictestproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private UserService userService;

    @GetMapping("/view/{user_id}")
    public ResponseEntity<Cart> viewCart(@PathVariable("user_id")int id){
        Users users = userService.findUserById(id);
        Cart cart = cartService.findCartByUser(users);
        return ResponseEntity.status(HttpStatus.OK).body(cart);
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateCart(@RequestBody Cart cart){
        cartService.updateCart(cart);
        return ResponseEntity.status(HttpStatus.OK).body(cart);
    }
}
