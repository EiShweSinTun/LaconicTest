package com.example.laconictestproject.controller;

import com.example.laconictestproject.entities.Role;
import com.example.laconictestproject.entities.Users;
import com.example.laconictestproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
public class UsersController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody Users users){
        if(userService.findUserByUsername(users.getUsername()) != null){
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        users.setRole(Role.USER);
        userService.createUser(users);
        return ResponseEntity.status(HttpStatus.OK).body(users);
    }

    @GetMapping("/view")
    public ResponseEntity<?> viewUser(@RequestBody Users users){
        return ResponseEntity.status(HttpStatus.OK).body(userService.findAllUser());
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateUser(@RequestBody Users users){
        userService.updateUser(users);
        return ResponseEntity.status(HttpStatus.OK).body(users);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteUser(@RequestBody Users users){
        userService.deleteUser(users);
        return ResponseEntity.status(HttpStatus.OK).body("User is Deleted");
    }
}
