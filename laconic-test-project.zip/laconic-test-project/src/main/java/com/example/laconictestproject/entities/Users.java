package com.example.laconictestproject.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int userId;
    @Column(unique = true)
    private String username;
    private String password;
    private String email;

    private String name;

    @Enumerated(EnumType.STRING)
    private Role role;

    @OneToOne
    private Cart cart;

    @OneToMany
    private List<Orders> ordersList;

    public void addOrderToList(Orders orders){
        ordersList.add(orders);
    }

}
