package com.example.laconictestproject.dao;

import com.example.laconictestproject.entities.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersDao extends JpaRepository<Users, Integer> {

    Users findByUsername(String username);
}
