package com.example.laconictestproject.service;

import com.example.laconictestproject.dao.OrdersDao;
import com.example.laconictestproject.entities.Orders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class OrdersService {

    @Autowired
    private OrdersDao ordersDao;

    @Transactional
    public void createOrder(Orders orders){
        ordersDao.save(orders);
    }

    @Transactional
    public void updateOrder(Orders orders){
        ordersDao.saveAndFlush(orders);
    }

    public Orders findOrderById(int id){
        return ordersDao.getById(id);
    }

    public List<Orders> getOrderList(){
        return ordersDao.findAll();
    }
}
